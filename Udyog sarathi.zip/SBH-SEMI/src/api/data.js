const Data= [
    {
        id:1,
        planName: "Free plan",
        price:"0",
        details:"For early-stage startups looking to combine data from a few sources",
        button:"GET STARTED FOR FREE",
        list1:"Free connectors, access to Postgres,Segments and Stripebon this plan.",
        list2:"An affordable way to provide you limited access on our website ",
        list3:"Limited offers and recommendation of jobs, so go fast and get hired!",
    },
    {
        id: 3,
        planName: "Enterprise",
        price:"999",
        details:"If you're looking for more access as an Enterprise company, contact us",
        button: "BUY NOW",
        list1:"Unlimited ad-free access to all over the website",
        list2:"Exclusive membership offers and other premium features",
        list3:"Premium recommendations for you only and stay updated!"

    },
]
export default Data;