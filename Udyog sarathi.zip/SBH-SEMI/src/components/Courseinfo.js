

const data = [
    {
        image:"https://res.cloudinary.com/drtqzmu2n/image/upload/v1696253128/Courses/GOVT./pic15_eujl6w.jpg",
        platform:"Accenture Pwd course",
        url:"https://www.accenture.com/in-en/careers/local/inclusion-diversity-pwd",
    },
    {
        image:"https://res.cloudinary.com/drtqzmu2n/image/upload/v1696252924/Courses/IT%20jobs/pic2_ypdaxu.webp",
        platform:"NIEMPD Special course",
        url:"https://niepmd.tn.nic.in/courses1.php",
    },
    {
        image:"https://res.cloudinary.com/drtqzmu2n/image/upload/v1696253126/Courses/GOVT./pic11_qmw1rh.webp",
        platform:"Wipro training course",
        url:"https://careers.wipro.com/pwd",
    }
   
]

export default data;

