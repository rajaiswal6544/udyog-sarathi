const data = [
    {
        image:"https://www.youtube.com/embed/yIW6eTU2oXY?si=0BzR2wA-hoi19GMy",
        heading:"Video 1"
    },
    {
        image:"https://www.youtube.com/embed/8lnZ88sYeLc?si=HFc0aNG8ROKQz6wl",
        heading:"Video 2"
    },
    {
        image:"https://www.youtube.com/embed/v4Nq-bLkvP8?si=JyFf8hZ0-aMvz6UX",
        heading:"Video 3"
    },
]

export default data;