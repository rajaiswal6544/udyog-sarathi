  const data=[
    {
        date:"30 April,2021",
        company:"Amazon",
        role:"System UI/UX Designer ",
        place:"Bengaluru, Tamil Nadu",
        salary:"50k - 80k"
    },
    {
        date:"30 April,2021",
        company:"Google",
        role:"Software Developer",
        place:"Gurgaon, Noida",
        salary:"1.5L - 2.5L"
    },
    {
        date:"30 April,2021",
        company:"Accenture",
        role:"Full Stack Developer",
        place:"Kolkata, West Bengal",
        salary:"30k - 40k"
    },
    {
        date:"30 April,2021",
        company:"LT Mindtree",
        role:"Cybersecurity",
        place:"Pune, Maharashtra",
        salary:"50k - 75k"
    },
    {
        date:"30 April,2021",
        company:"Well Fargos",
        role:"Data Analyst",
        place:"Bengaluru, Tamil Nadu",
        salary:"1.2L - 1.7L"
    },
    {
        date:"30 April,2021",
        company:"Razorpay",
        role:"Intern Software Developer",
        place:"Mumbai, Maharashtra",
        salary:"1.3L - 2L"
    }
]

export default data;
