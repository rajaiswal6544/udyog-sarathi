export const filterData=
[
    {
        id:"1",
        title:"All"
    },
    {
        id:"2",
        title:"IT"
    },
    {
        id:"3",
        title:"Non IT"
    },
    {
        id:"4",
        title:"Govt."
    },
];